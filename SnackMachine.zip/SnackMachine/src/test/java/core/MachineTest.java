package core;

import junit.framework.TestCase;
import products.Product;

import java.util.List;

public class MachineTest extends TestCase {

    public void testAddProduct() {

//        Machine machine = new Machine();
//
//        Product product1 = new Product(),
//                product2 = new Product(),
//                product3 = new Product();
//
//        machine.addProduct(product1);
//        machine.addProduct(product2);
//        machine.addProduct(product3);
//
//        List<Product> products = machine.getProducts();
//        System.out.println(products.size());
    }
}