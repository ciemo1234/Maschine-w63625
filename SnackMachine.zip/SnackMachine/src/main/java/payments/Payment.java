package payments;

public interface Payment {
    public boolean makePayment(Double amount);
}
